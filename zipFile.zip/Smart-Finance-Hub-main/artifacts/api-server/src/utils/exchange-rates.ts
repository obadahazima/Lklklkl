type Rates = { usdToAed: number; sypToAed: number };

let cache: { rates: Rates; fetchedAt: number } | null = null;
const CACHE_TTL = 60 * 60 * 1000;

const FALLBACK: Rates = { usdToAed: 3.67, sypToAed: 0.000077 };

export async function getExchangeRates(): Promise<Rates> {
  if (cache && Date.now() - cache.fetchedAt < CACHE_TTL) {
    return cache.rates;
  }
  try {
    const resp = await fetch("https://open.er-api.com/v6/latest/AED");
    const data = (await resp.json()) as { result: string; rates: Record<string, number> };
    if (data.result === "success" && data.rates) {
      const r: Rates = {
        usdToAed: data.rates["USD"] ? 1 / data.rates["USD"] : FALLBACK.usdToAed,
        sypToAed: data.rates["SYP"] ? 1 / data.rates["SYP"] : FALLBACK.sypToAed,
      };
      cache = { rates: r, fetchedAt: Date.now() };
      return r;
    }
  } catch {
    // fall through to fallback
  }
  return FALLBACK;
}

export function toAed(amount: number, currency: string, rates: Rates): number {
  if (currency === "AED") return amount;
  if (currency === "USD") return amount * rates.usdToAed;
  if (currency === "SYP") return amount * rates.sypToAed;
  return amount;
}
