import { Router } from "express";
import { db } from "@workspace/db";
import { transactionsTable, clientsTable, tripsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { getExchangeRates, toAed } from "../utils/exchange-rates.js";

const router = Router();

router.get("/dashboard/summary", async (req, res): Promise<void> => {
  try {
    const [txs, allClients, trips, rates] = await Promise.all([
      db.select().from(transactionsTable),
      db.select().from(clientsTable),
      db.select().from(tripsTable),
      getExchangeRates(),
    ]);

    const currencies = ["AED", "USD", "SYP"];
    const currencyData = currencies.map((currency) => {
      const currTxs = txs.filter((t) => t.currency === currency);
      const totalIncome = currTxs
        .filter((t) => t.type === "income" || t.type === "receipt")
        .reduce((sum, t) => sum + Number(t.amount), 0);
      const totalExpenses = currTxs
        .filter((t) => t.type === "expense" || t.type === "payment")
        .reduce((sum, t) => sum + Number(t.amount), 0);
      return { currency, totalIncome, totalExpenses, balance: totalIncome - totalExpenses };
    });

    const totalBalanceAED = currencyData.reduce(
      (sum, c) => sum + toAed(c.balance, c.currency, rates),
      0
    );

    const pendingTransactions = txs.filter((t) => t.status === "pending").length;
    const activeTrips = trips.filter((t) => t.status === "active").length;

    res.json({
      currencies: currencyData,
      totalClients: allClients.length,
      totalTrips: trips.length,
      activeTrips,
      pendingTransactions,
      totalBalanceAED: Math.round(totalBalanceAED * 100) / 100,
      exchangeRates: rates,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get dashboard summary");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/dashboard/recent-transactions", async (req, res): Promise<void> => {
  try {
    const txs = await db
      .select()
      .from(transactionsTable)
      .orderBy(desc(transactionsTable.createdAt))
      .limit(10);

    const enriched = await Promise.all(
      txs.map(async (t) => {
        let clientName: string | null = null;
        let tripName: string | null = null;
        if (t.clientId) {
          const [c] = await db.select({ name: clientsTable.name }).from(clientsTable).where(eq(clientsTable.id, t.clientId));
          clientName = c?.name ?? null;
        }
        if (t.tripId) {
          const [tr] = await db.select({ name: tripsTable.name }).from(tripsTable).where(eq(tripsTable.id, t.tripId));
          tripName = tr?.name ?? null;
        }
        return {
          ...t,
          amount: Number(t.amount),
          clientName,
          tripName,
          studioName: null,
          createdAt: t.createdAt.toISOString(),
        };
      })
    );

    res.json(enriched);
  } catch (err) {
    req.log.error({ err }, "Failed to get recent transactions");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
