import { Router } from "express";
import { db } from "@workspace/db";
import { transactionsTable, clientsTable, tripsTable } from "@workspace/db";
import { ParseVoiceInputBody, AiQueryBody } from "@workspace/api-zod";
import { GoogleGenerativeAI } from "@google/generative-ai";

const router = Router();

function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY is not set");
  return new GoogleGenerativeAI(apiKey);
}

router.post("/ai/parse-voice", async (req, res): Promise<void> => {
  const parsed = ParseVoiceInputBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { text } = parsed.data;

  try {
    const genAI = getGeminiClient();
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

    const prompt = `أنتِ مساعدة مالية ذكية. قومي بتحليل الجملة التالية واستخراج بيانات العملية المالية منها.

الجملة: "${text}"

استخرجي المعلومات التالية بتنسيق JSON فقط بدون أي نص إضافي:
- type: نوع العملية (income = دخل/إيراد، expense = مصروف/شراء، payment = دفع لزبون، receipt = قبض من زبون)
- amount: المبلغ كرقم فقط
- currency: العملة (AED للدرهم، USD للدولار، SYP للليرة السورية)
- clientName: اسم الزبون إن وجد (null إن لم يوجد)
- tripName: اسم الرحلة إن وجد (null إن لم يوجد)
- description: وصف مختصر للعملية

مثال للإخراج:
{"type":"expense","amount":1000,"currency":"AED","clientName":"رشا","tripName":"رحلة دبي","description":"شراء بضاعة لرشا"}`;

    const result = await model.generateContent(prompt);
    const responseText = result.response.text().trim();

    let jsonText = responseText;
    const jsonMatch = responseText.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (jsonMatch) jsonText = jsonMatch[1].trim();

    let parsedResult: Record<string, unknown> = {};
    try {
      parsedResult = JSON.parse(jsonText) as Record<string, unknown>;
    } catch {
      res.json({ success: false, error: "فشل تحليل النص", rawText: text });
      return;
    }

    res.json({
      success: true,
      type: (parsedResult.type as string) || null,
      amount: (parsedResult.amount as number) || null,
      currency: (parsedResult.currency as string) || null,
      clientName: (parsedResult.clientName as string) || null,
      tripName: (parsedResult.tripName as string) || null,
      description: (parsedResult.description as string) || null,
      rawText: text,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to parse voice input");
    res.status(500).json({ error: "فشل تحليل الإدخال الصوتي" });
  }
});

router.post("/ai/query", async (req, res): Promise<void> => {
  const parsed = AiQueryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { question } = parsed.data;

  try {
    const genAI = getGeminiClient();
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

    const txs = await db.select().from(transactionsTable);
    const clients = await db.select().from(clientsTable);
    const trips = await db.select().from(tripsTable);

    const currencies = ["AED", "USD", "SYP"];
    const balances = currencies.map((currency) => {
      const currTxs = txs.filter((t) => t.currency === currency);
      const income = currTxs.filter((t) => t.type === "income" || t.type === "receipt").reduce((s, t) => s + Number(t.amount), 0);
      const expenses = currTxs.filter((t) => t.type === "expense" || t.type === "payment").reduce((s, t) => s + Number(t.amount), 0);
      return { currency, balance: income - expenses, income, expenses };
    });

    const clientSummaries = clients.map((client) => {
      const clientTxs = txs.filter((t) => t.clientId === client.id);
      const perCurrency = currencies
        .map((c) => {
          const cTxs = clientTxs.filter((t) => t.currency === c);
          const paid = cTxs.filter((t) => t.type === "expense" || t.type === "payment").reduce((s, t) => s + Number(t.amount), 0);
          const received = cTxs.filter((t) => t.type === "income" || t.type === "receipt").reduce((s, t) => s + Number(t.amount), 0);
          return { currency: c, paid, received, open: received - paid };
        })
        .filter((c) => c.paid !== 0 || c.received !== 0);
      return { name: client.name, balances: perCurrency };
    });

    const context = `
بيانات مالية حالية:

الأرصدة الإجمالية:
${balances.map((b) => `- ${b.currency}: رصيد ${b.balance.toFixed(2)} (دخل: ${b.income.toFixed(2)}, مصاريف: ${b.expenses.toFixed(2)})`).join("\n")}

الزبائن (${clients.length} زبون):
${clientSummaries.map((c) => `- ${c.name}: ${c.balances.map((b) => `${b.currency}: مدفوع ${b.paid}, مقبوض ${b.received}, مفتوح ${b.open}`).join(" | ")}`).join("\n") || "لا يوجد زبائن"}

الرحلات (${trips.length} رحلة):
${trips.map((t) => `- ${t.name}: ${t.status === "active" ? "نشطة" : "مغلقة"}${t.isShared ? " (مشتركة)" : ""}`).join("\n") || "لا توجد رحلات"}

المعاملات المعلقة: ${txs.filter((t) => t.status === "pending").length}
إجمالي المعاملات: ${txs.length}
`;

    const prompt = `أنتِ مساعدة مالية ذكية لتاجرة تعمل بين بلدين. أجيبي على الأسئلة بدقة بناءً على البيانات المالية المقدمة. أجيبي بالعربية بشكل موجز ودقيق.

البيانات المالية:
${context}

السؤال: ${question}`;

    const result = await model.generateContent(prompt);
    const answer = result.response.text();

    res.json({ answer, data: { balances, clientCount: clients.length } });
  } catch (err) {
    req.log.error({ err }, "Failed to process AI query");
    res.status(500).json({ error: "فشل معالجة الاستعلام" });
  }
});

export default router;
