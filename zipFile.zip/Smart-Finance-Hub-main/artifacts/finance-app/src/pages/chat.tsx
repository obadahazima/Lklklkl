import { useState, useRef, useEffect } from "react";
import { useAiQuery } from "@workspace/api-client-react";
import { Mic, MicOff, Send, Bot, User, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

type Message = {
  id: number;
  role: "user" | "assistant";
  content: string;
};

const QUICK_QUESTIONS = [
  "كم دولار أملك؟",
  "كم درهم أملك؟",
  "ما هو الرصيد الإجمالي؟",
  "كم عدد الزبائن؟",
  "ما هي الرحلات النشطة؟",
];

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([
    { id: 0, role: "assistant", content: "مرحباً! أنا مساعدتك المالية الذكية. يمكنني الإجابة على أسئلتك حول حساباتك. اسأليني مثلاً: \"كم دولار أملك؟\" أو \"ما هي ذمة رشا؟\"" },
  ]);
  const [input, setInput] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const { toast } = useToast();

  const queryMutation = useAiQuery({
    mutation: {
      onSuccess: (data) => {
        setMessages((prev) => [...prev, { id: Date.now(), role: "assistant", content: data.answer }]);
      },
      onError: () => {
        setMessages((prev) => [...prev, { id: Date.now(), role: "assistant", content: "عذراً، حدث خطأ. تأكدي من إضافة مفتاح Gemini API." }]);
      },
    },
  });

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  function sendMessage(text: string) {
    if (!text.trim()) return;
    const userMsg: Message = { id: Date.now(), role: "user", content: text };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    queryMutation.mutate({ data: { question: text } });
  }

  function startVoice() {
    type SpeechRecognitionCtor = new () => SpeechRecognition;
    const w = window as Window & { SpeechRecognition?: SpeechRecognitionCtor; webkitSpeechRecognition?: SpeechRecognitionCtor };
    const Ctor = w.SpeechRecognition ?? w.webkitSpeechRecognition;
    if (!Ctor) {
      toast({ title: "غير مدعوم", description: "متصفحك لا يدعم التسجيل الصوتي", variant: "destructive" });
      return;
    }
    const recognition = new Ctor();
    recognition.lang = "ar-AE";
    recognition.interimResults = false;
    recognition.onstart = () => setIsRecording(true);
    recognition.onend = () => setIsRecording(false);
    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results[0][0].transcript;
      sendMessage(transcript);
    };
    recognition.onerror = () => {
      setIsRecording(false);
      toast({ title: "خطأ في التسجيل", variant: "destructive" });
    };
    recognition.start();
    recognitionRef.current = recognition;
  }

  function stopVoice() {
    recognitionRef.current?.stop();
    setIsRecording(false);
  }

  return (
    <div className="flex flex-col h-full max-w-2xl mx-auto">
      {/* Header */}
      <div className="px-4 py-4 border-b border-border bg-card shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Bot className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="font-bold text-foreground">المساعد الذكي</h1>
            <p className="text-xs text-green-500 font-medium">متصل • Gemini AI</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={cn("flex gap-3", msg.role === "user" ? "flex-row-reverse" : "flex-row")}
            data-testid={`msg-${msg.id}`}
          >
            <div className={cn(
              "w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-0.5",
              msg.role === "assistant" ? "bg-primary/10" : "bg-muted"
            )}>
              {msg.role === "assistant" ? <Bot className="w-4 h-4 text-primary" /> : <User className="w-4 h-4 text-muted-foreground" />}
            </div>
            <div className={cn(
              "max-w-[80%] px-4 py-3 rounded-2xl text-sm leading-relaxed",
              msg.role === "assistant"
                ? "bg-card border border-border text-foreground rounded-tr-sm"
                : "bg-primary text-primary-foreground rounded-tl-sm"
            )}>
              {msg.content}
            </div>
          </div>
        ))}
        {queryMutation.isPending && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-primary" />
            </div>
            <div className="bg-card border border-border px-4 py-3 rounded-2xl rounded-tr-sm">
              <Loader2 className="w-4 h-4 text-muted-foreground animate-spin" />
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Quick questions */}
      <div className="px-4 pb-2 flex gap-2 overflow-x-auto shrink-0">
        {QUICK_QUESTIONS.map((q) => (
          <button
            key={q}
            onClick={() => sendMessage(q)}
            disabled={queryMutation.isPending}
            className="shrink-0 text-xs bg-accent text-accent-foreground px-3 py-1.5 rounded-full border border-border hover:bg-primary/10 transition-colors disabled:opacity-50"
            data-testid={`quick-q-${q}`}
          >
            {q}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="px-4 pb-4 pt-2 border-t border-border bg-card shrink-0">
        <div className="flex items-center gap-2">
          <button
            onMouseDown={startVoice}
            onMouseUp={stopVoice}
            onTouchStart={startVoice}
            onTouchEnd={stopVoice}
            className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center transition-all shrink-0",
              isRecording ? "bg-red-500 animate-recording" : "bg-muted hover:bg-muted/80"
            )}
            data-testid="btn-voice-chat"
          >
            {isRecording ? <MicOff className="w-4 h-4 text-white" /> : <Mic className="w-4 h-4 text-muted-foreground" />}
          </button>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage(input)}
            placeholder='اسأليني مثلاً: "كم دولار أملك؟"'
            className="flex-1 border border-border rounded-xl px-4 py-2.5 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-primary/30"
            data-testid="input-chat"
          />
          <button
            onClick={() => sendMessage(input)}
            disabled={!input.trim() || queryMutation.isPending}
            className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center disabled:opacity-50 shrink-0"
            data-testid="btn-send-chat"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
