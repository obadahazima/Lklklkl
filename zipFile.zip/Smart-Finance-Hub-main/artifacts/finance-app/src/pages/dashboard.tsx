import { useGetDashboardSummary, useGetRecentTransactions } from "@workspace/api-client-react";
import { formatAmount, currencyClass, typeLabel, typeClass, statusLabel, statusClass, formatDate } from "@/lib/utils";
import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown, Wallet, Users, Route, Clock, ArrowLeftRight, RefreshCw } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: summary, isLoading: loadingSummary } = useGetDashboardSummary();
  const { data: recent, isLoading: loadingRecent } = useGetRecentTransactions();

  const rates = summary?.exchangeRates;

  return (
    <div className="p-4 space-y-5 max-w-2xl mx-auto pb-24 lg:pb-6">
      {/* Header */}
      <div className="pt-2">
        <h1 className="text-2xl font-bold text-foreground">لوحة التحكم</h1>
        <p className="text-muted-foreground text-sm mt-1">نظرة عامة على حساباتك</p>
      </div>

      {/* ── Total AED Wallet Card ── */}
      {loadingSummary ? (
        <div className="h-28 bg-card rounded-2xl border border-border animate-pulse" />
      ) : summary ? (
        <div className="bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Wallet className="w-5 h-5 text-primary" />
              <span className="font-bold text-foreground">إجمالي المحفظة</span>
            </div>
            <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">بالدرهم AED</span>
          </div>
          <p
            className={cn(
              "text-3xl font-bold mt-1",
              summary.totalBalanceAED >= 0 ? "text-green-600" : "text-red-600"
            )}
            data-testid="total-balance-aed"
          >
            {summary.totalBalanceAED < 0 ? "-" : ""}
            {formatAmount(Math.abs(summary.totalBalanceAED), "AED")}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            {summary.totalBalanceAED >= 0 ? "لك (إجمالي)" : "عليك (إجمالي)"}
          </p>
          {rates && (
            <div className="flex gap-4 mt-3 pt-3 border-t border-primary/10">
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <RefreshCw className="w-3 h-3" />
                <span>1 USD = {rates.usdToAed.toFixed(2)} AED</span>
              </div>
              <div className="text-xs text-muted-foreground">
                <span>1000 SYP = {(rates.sypToAed * 1000).toFixed(2)} AED</span>
              </div>
            </div>
          )}
        </div>
      ) : null}

      {/* Currency breakdown cards */}
      <section>
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">تفاصيل الأرصدة</h2>
        {loadingSummary ? (
          <div className="grid grid-cols-1 gap-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-28 bg-card rounded-2xl border border-border animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3">
            {summary?.currencies
              .filter((c) => c.totalIncome > 0 || c.totalExpenses > 0)
              .map((c) => {
                const inAed = rates
                  ? c.currency === "AED"
                    ? c.balance
                    : c.currency === "USD"
                    ? c.balance * rates.usdToAed
                    : c.balance * rates.sypToAed
                  : null;
                return (
                  <div
                    key={c.currency}
                    className="bg-card border border-border rounded-2xl p-4 shadow-sm"
                    data-testid={`card-currency-${c.currency}`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className={cn("text-xs font-bold px-2.5 py-1 rounded-full", currencyClass(c.currency))}>
                        {c.currency}
                      </span>
                      <div className="text-left">
                        <p className={cn("text-xl font-bold", c.balance >= 0 ? "text-green-600" : "text-red-600")}>
                          {c.balance < 0 ? "-" : ""}{formatAmount(Math.abs(c.balance), c.currency)}
                        </p>
                        {inAed !== null && c.currency !== "AED" && (
                          <p className="text-xs text-muted-foreground text-right">
                            ≈ {formatAmount(Math.abs(inAed), "AED")}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <div className="flex items-center gap-1.5">
                        <TrendingUp className="w-3.5 h-3.5 text-green-500" />
                        <span className="text-xs text-muted-foreground">دخل:</span>
                        <span className="text-xs font-semibold text-green-600">{formatAmount(c.totalIncome, c.currency)}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <TrendingDown className="w-3.5 h-3.5 text-red-500" />
                        <span className="text-xs text-muted-foreground">مصروف:</span>
                        <span className="text-xs font-semibold text-red-600">{formatAmount(c.totalExpenses, c.currency)}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            {summary?.currencies.every((c) => c.totalIncome === 0 && c.totalExpenses === 0) && (
              <div className="bg-card border border-border rounded-2xl p-6 text-center">
                <Wallet className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
                <p className="text-muted-foreground text-sm">لا توجد معاملات بعد</p>
              </div>
            )}
          </div>
        )}
      </section>

      {/* Stats row */}
      {summary && (
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-card border border-border rounded-xl p-3 text-center" data-testid="stat-clients">
            <Users className="w-5 h-5 text-primary mx-auto mb-1" />
            <p className="text-xl font-bold text-foreground">{summary.totalClients}</p>
            <p className="text-xs text-muted-foreground">زبون</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-3 text-center" data-testid="stat-active-trips">
            <Route className="w-5 h-5 text-blue-500 mx-auto mb-1" />
            <p className="text-xl font-bold text-foreground">{summary.activeTrips}</p>
            <p className="text-xs text-muted-foreground">رحلة نشطة</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-3 text-center" data-testid="stat-pending">
            <Clock className="w-5 h-5 text-amber-500 mx-auto mb-1" />
            <p className="text-xl font-bold text-foreground">{summary.pendingTransactions}</p>
            <p className="text-xs text-muted-foreground">معلقة</p>
          </div>
        </div>
      )}

      {/* Recent transactions */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">آخر المعاملات</h2>
          <Link href="/transactions">
            <span className="text-xs text-primary font-medium">عرض الكل</span>
          </Link>
        </div>
        <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
          {loadingRecent ? (
            <div className="divide-y divide-border">
              {[1, 2, 3].map((i) => (
                <div key={i} className="p-4 animate-pulse">
                  <div className="h-4 bg-muted rounded w-1/2 mb-2" />
                  <div className="h-3 bg-muted rounded w-1/3" />
                </div>
              ))}
            </div>
          ) : recent?.length === 0 ? (
            <div className="p-8 text-center">
              <ArrowLeftRight className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
              <p className="text-muted-foreground text-sm">لا توجد معاملات بعد</p>
              <Link href="/transactions/new">
                <span className="text-primary text-sm font-medium">أضف معاملة</span>
              </Link>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {recent?.map((tx) => (
                <div key={tx.id} className="p-4 flex items-center gap-3" data-testid={`tx-row-${tx.id}`}>
                  <div
                    className={cn("w-2 h-2 rounded-full shrink-0 mt-0.5", {
                      "bg-green-500": tx.type === "income",
                      "bg-red-500": tx.type === "expense",
                      "bg-blue-500": tx.type === "payment",
                      "bg-emerald-500": tx.type === "receipt",
                    })}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className={cn("text-sm font-semibold", typeClass(tx.type))}>{typeLabel(tx.type)}</span>
                      {tx.clientName && <span className="text-xs text-muted-foreground truncate">{tx.clientName}</span>}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">{formatDate(tx.date)}</span>
                      {tx.tripName && <span className="text-xs text-blue-500 truncate">{tx.tripName}</span>}
                    </div>
                  </div>
                  <div className="text-left shrink-0">
                    <p className={cn("text-sm font-bold", typeClass(tx.type))}>
                      {tx.type === "expense" || tx.type === "payment" ? "-" : "+"}
                      {formatAmount(tx.amount, tx.currency)}
                    </p>
                    <span className={cn("text-[10px] px-1.5 py-0.5 rounded-full font-medium", statusClass(tx.status))}>
                      {statusLabel(tx.status)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
