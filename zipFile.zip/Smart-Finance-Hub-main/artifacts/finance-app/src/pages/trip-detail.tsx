import { useGetTripPnl, getGetTripPnlQueryKey } from "@workspace/api-client-react";
import { useParams, useLocation } from "wouter";
import { formatAmount, currencyClass, cn } from "@/lib/utils";
import { ChevronRight, TrendingUp, TrendingDown, Divide } from "lucide-react";

export default function TripDetail() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const id = parseInt(params.id);

  const { data, isLoading } = useGetTripPnl(id, {
    query: { enabled: !!id, queryKey: getGetTripPnlQueryKey(id) },
  });

  if (isLoading) {
    return (
      <div className="p-4 space-y-4 max-w-2xl mx-auto">
        <div className="h-8 bg-muted rounded animate-pulse w-1/2" />
        <div className="h-40 bg-muted rounded-2xl animate-pulse" />
      </div>
    );
  }

  if (!data) return <div className="p-4 text-center text-muted-foreground">لم يتم العثور على الرحلة</div>;

  const { trip, breakdown } = data;

  return (
    <div className="p-4 space-y-5 max-w-2xl mx-auto pb-24 lg:pb-6">
      <div className="flex items-center gap-3 pt-2">
        <button onClick={() => setLocation("/trips")} className="p-2 rounded-lg hover:bg-muted text-muted-foreground">
          <ChevronRight className="w-5 h-5" />
        </button>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold">{trip.name}</h1>
            {trip.isShared && (
              <span className="text-xs bg-purple-100 text-purple-700 border border-purple-200 px-2 py-0.5 rounded-full font-medium">
                مشتركة
              </span>
            )}
          </div>
          <p className="text-xs text-muted-foreground">الأرباح والخسائر</p>
        </div>
      </div>

      {trip.isShared && (
        <div className="flex items-center gap-2 bg-purple-50 border border-purple-200 rounded-xl px-4 py-3">
          <Divide className="w-4 h-4 text-purple-600 shrink-0" />
          <p className="text-sm text-purple-700">رحلة مشتركة — صافي الربح يُقسّم على 2</p>
        </div>
      )}

      {breakdown.length === 0 ? (
        <div className="bg-card border border-border rounded-2xl p-8 text-center">
          <p className="text-muted-foreground">لا توجد معاملات لهذه الرحلة بعد</p>
        </div>
      ) : (
        <div className="space-y-4">
          {breakdown.map((b) => (
            <div key={b.currency} className="bg-card border border-border rounded-2xl p-5 shadow-sm" data-testid={`pnl-${b.currency}`}>
              <div className="flex items-center justify-between mb-4">
                <span className={cn("text-xs font-bold px-2.5 py-1 rounded-full", currencyClass(b.currency))}>{b.currency}</span>
                <div className="text-left">
                  <p className="text-xs text-muted-foreground">الربح الصافي</p>
                  <p className={cn("text-xl font-bold", b.netProfit >= 0 ? "text-green-600" : "text-red-600")}>
                    {b.netProfit >= 0 ? "+" : ""}{formatAmount(b.netProfit, b.currency)}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-3">
                <div className="bg-green-50 rounded-xl p-3">
                  <div className="flex items-center gap-1.5 mb-1">
                    <TrendingUp className="w-3.5 h-3.5 text-green-600" />
                    <span className="text-xs text-green-700 font-medium">الإيرادات</span>
                  </div>
                  <p className="text-base font-bold text-green-700">{formatAmount(b.revenue, b.currency)}</p>
                </div>
                <div className="bg-red-50 rounded-xl p-3">
                  <div className="flex items-center gap-1.5 mb-1">
                    <TrendingDown className="w-3.5 h-3.5 text-red-600" />
                    <span className="text-xs text-red-700 font-medium">المصاريف</span>
                  </div>
                  <p className="text-base font-bold text-red-700">{formatAmount(b.expenses, b.currency)}</p>
                </div>
              </div>

              {trip.isShared && (
                <div className="bg-purple-50 border border-purple-200 rounded-xl p-3">
                  <p className="text-xs text-purple-600 font-medium mb-1">نصيبك (بعد القسمة)</p>
                  <p className={cn("text-lg font-bold", b.myShare >= 0 ? "text-purple-700" : "text-red-600")}>
                    {b.myShare >= 0 ? "+" : ""}{formatAmount(b.myShare, b.currency)}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
