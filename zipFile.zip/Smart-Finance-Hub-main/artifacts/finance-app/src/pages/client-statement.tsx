import { useGetClientStatement, getGetClientStatementQueryKey } from "@workspace/api-client-react";
import { useParams, useLocation } from "wouter";
import {
  formatAmount,
  currencyClass,
  typeLabel,
  typeClass,
  statusLabel,
  statusClass,
  formatDate,
  cn,
} from "@/lib/utils";
import { ChevronRight, TrendingDown, TrendingUp, Minus, Wallet, RefreshCw } from "lucide-react";

export default function ClientStatement() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const id = parseInt(params.id);

  const { data, isLoading } = useGetClientStatement(id, {
    query: { enabled: !!id, queryKey: getGetClientStatementQueryKey(id) },
  });

  if (isLoading) {
    return (
      <div className="p-4 space-y-4 max-w-2xl mx-auto">
        <div className="h-8 bg-muted rounded animate-pulse w-1/3" />
        <div className="h-28 bg-muted rounded-2xl animate-pulse" />
        <div className="h-40 bg-muted rounded-2xl animate-pulse" />
      </div>
    );
  }

  if (!data) return <div className="p-4 text-center text-muted-foreground">لم يتم العثور على الزبون</div>;

  const { client, transactions, balances, totalBalanceAED, exchangeRates } = data;

  return (
    <div className="p-4 space-y-5 max-w-2xl mx-auto pb-24 lg:pb-6">
      {/* Header */}
      <div className="flex items-center gap-3 pt-2">
        <button
          onClick={() => setLocation("/clients")}
          className="p-2 rounded-lg hover:bg-muted text-muted-foreground"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
              {client.name.charAt(0)}
            </div>
            <div>
              <h1 className="text-xl font-bold">{client.name}</h1>
              <p className="text-xs text-muted-foreground">{client.phone ?? "كشف الحساب"}</p>
            </div>
          </div>
        </div>
      </div>

      {/* ── Total AED Summary Card ── */}
      <div
        className={cn(
          "rounded-2xl p-5 border shadow-sm",
          totalBalanceAED === 0
            ? "bg-muted/40 border-border"
            : totalBalanceAED > 0
            ? "bg-gradient-to-br from-green-50 to-green-100/50 border-green-200 dark:from-green-900/20 dark:to-green-800/10 dark:border-green-800/40"
            : "bg-gradient-to-br from-red-50 to-red-100/50 border-red-200 dark:from-red-900/20 dark:to-red-800/10 dark:border-red-800/40"
        )}
        data-testid="total-aed-card"
      >
        <div className="flex items-center gap-2 mb-2">
          <Wallet className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-semibold text-muted-foreground">الإجمالي بالدرهم</span>
          <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full mr-auto">AED</span>
        </div>
        <p
          className={cn(
            "text-3xl font-bold",
            totalBalanceAED === 0
              ? "text-foreground"
              : totalBalanceAED > 0
              ? "text-green-600"
              : "text-red-600"
          )}
        >
          {totalBalanceAED === 0
            ? "مسدد بالكامل"
            : totalBalanceAED > 0
            ? `له ${formatAmount(totalBalanceAED, "AED")}`
            : `عليه ${formatAmount(Math.abs(totalBalanceAED), "AED")}`}
        </p>
        {balances.length > 0 && totalBalanceAED !== 0 && (
          <p className="text-xs text-muted-foreground mt-1">
            مجموع كل العملات محوّلاً للدرهم
          </p>
        )}
        {exchangeRates && balances.some((b) => b.currency !== "AED") && (
          <div className="flex flex-wrap gap-3 mt-3 pt-3 border-t border-black/5 dark:border-white/10">
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <RefreshCw className="w-3 h-3" />
              <span>1 USD = {exchangeRates.usdToAed.toFixed(2)} AED</span>
            </div>
            <div className="text-xs text-muted-foreground">
              1000 SYP = {(exchangeRates.sypToAed * 1000).toFixed(2)} AED
            </div>
          </div>
        )}
      </div>

      {/* Per-currency balances */}
      {balances.length > 0 ? (
        <section>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
            الأرصدة المفتوحة بالعملة
          </h2>
          <div className="space-y-3">
            {balances.map((b) => {
              const inAed =
                b.currency === "AED"
                  ? b.openBalance
                  : b.currency === "USD"
                  ? b.openBalance * (exchangeRates?.usdToAed ?? 3.67)
                  : b.openBalance * (exchangeRates?.sypToAed ?? 0.000077);
              return (
                <div
                  key={b.currency}
                  className="bg-card border border-border rounded-2xl p-4 shadow-sm"
                  data-testid={`balance-${b.currency}`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className={cn("text-xs font-bold px-2.5 py-1 rounded-full", currencyClass(b.currency))}>
                      {b.currency}
                    </span>
                    <div className="text-left">
                      <span
                        className={cn("text-lg font-bold block", b.openBalance >= 0 ? "text-green-600" : "text-red-600")}
                      >
                        {b.openBalance === 0
                          ? "مسدد"
                          : b.openBalance > 0
                          ? `له ${formatAmount(b.openBalance, b.currency)}`
                          : `عليه ${formatAmount(Math.abs(b.openBalance), b.currency)}`}
                      </span>
                      {b.currency !== "AED" && b.openBalance !== 0 && (
                        <span className="text-xs text-muted-foreground text-right">
                          ≈ {formatAmount(Math.abs(inAed), "AED")}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex items-center gap-1.5">
                      <TrendingDown className="w-3.5 h-3.5 text-red-500" />
                      <span className="text-xs text-muted-foreground">مدفوع: </span>
                      <span className="text-xs font-semibold text-red-600">{formatAmount(b.paid, b.currency)}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <TrendingUp className="w-3.5 h-3.5 text-green-500" />
                      <span className="text-xs text-muted-foreground">مقبوض: </span>
                      <span className="text-xs font-semibold text-green-600">
                        {formatAmount(b.received, b.currency)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      ) : (
        <div className="bg-card border border-border rounded-2xl p-6 text-center">
          <Minus className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
          <p className="text-muted-foreground text-sm">لا توجد أرصدة مفتوحة</p>
        </div>
      )}

      {/* Transactions list */}
      <section>
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
          المعاملات ({transactions.length})
        </h2>
        {transactions.length === 0 ? (
          <div className="bg-card border border-border rounded-2xl p-8 text-center">
            <p className="text-muted-foreground text-sm">لا توجد معاملات لهذا الزبون</p>
          </div>
        ) : (
          <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
            <div className="divide-y divide-border">
              {transactions.map((tx) => (
                <div
                  key={tx.id}
                  className="p-4 flex items-center gap-3"
                  data-testid={`stmt-tx-${tx.id}`}
                >
                  <div
                    className={cn("w-2 h-2 rounded-full shrink-0", {
                      "bg-green-500": tx.type === "income",
                      "bg-red-500": tx.type === "expense",
                      "bg-blue-500": tx.type === "payment",
                      "bg-emerald-500": tx.type === "receipt",
                    })}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={cn("text-sm font-semibold", typeClass(tx.type))}>
                        {typeLabel(tx.type)}
                      </span>
                      <span
                        className={cn("text-[10px] px-1.5 py-0.5 rounded-full", statusClass(tx.status))}
                      >
                        {statusLabel(tx.status)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs text-muted-foreground">{formatDate(tx.date)}</span>
                      {tx.tripName && <span className="text-xs text-blue-500">{tx.tripName}</span>}
                    </div>
                    {tx.description && (
                      <p className="text-xs text-muted-foreground mt-0.5 truncate">{tx.description}</p>
                    )}
                  </div>
                  <div className="shrink-0 text-left">
                    <span className={cn("text-sm font-bold", typeClass(tx.type))}>
                      {tx.type === "expense" || tx.type === "payment" ? "-" : "+"}
                      {formatAmount(tx.amount, tx.currency)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
