import { useState, useRef } from "react";
import {
  useParseVoiceInput,
  useCreateTransaction,
  useCreateClient,
  useListClients,
  useListTrips,
  getListTransactionsQueryKey,
  getGetDashboardSummaryQueryKey,
  getGetRecentTransactionsQueryKey,
  getListClientsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import {
  Mic,
  MicOff,
  Loader2,
  CheckCircle,
  XCircle,
  ChevronRight,
  UserPlus,
  Users,
} from "lucide-react";
import { cn, typeLabel, currencyClass, formatAmount } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

type ParsedData = {
  type?: string | null;
  amount?: number | null;
  currency?: string | null;
  clientName?: string | null;
  tripName?: string | null;
  description?: string | null;
  rawText?: string | null;
};

type ClientResolutionState =
  | { kind: "idle" }
  | { kind: "similar"; matches: { id: number; name: string }[]; inputName: string }
  | { kind: "new"; name: string };

export default function NewTransaction() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [step, setStep] = useState<"input" | "confirm">("input");
  const [textInput, setTextInput] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [parsed, setParsed] = useState<ParsedData | null>(null);

  // Client resolution modal state
  const [clientResolution, setClientResolution] = useState<ClientResolutionState>({ kind: "idle" });
  const [newClientPhone, setNewClientPhone] = useState("");
  const [resolvedClientId, setResolvedClientId] = useState<number | null | undefined>(undefined);

  // Pending transaction payload waiting for client resolution
  const pendingTxRef = useRef<Parameters<ReturnType<typeof useCreateTransaction>["mutate"]>[0] | null>(null);

  const [manualForm, setManualForm] = useState({
    type: "expense",
    amount: "",
    currency: "AED",
    clientId: "",
    tripId: "",
    description: "",
    status: "pending",
    date: new Date().toISOString().split("T")[0],
  });

  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const { data: clients } = useListClients();
  const { data: trips } = useListTrips();

  const parseMutation = useParseVoiceInput({
    mutation: {
      onSuccess: (data) => {
        if (data.success) {
          setParsed(data);
          setStep("confirm");
        } else {
          toast({ title: "لم أفهم", description: data.error || "حاولي مرة أخرى", variant: "destructive" });
        }
      },
      onError: () => {
        toast({ title: "خطأ في التحليل", description: "حاولي مرة أخرى", variant: "destructive" });
      },
    },
  });

  const createClientMutation = useCreateClient({
    mutation: {
      onSuccess: (newClient) => {
        queryClient.invalidateQueries({ queryKey: getListClientsQueryKey() });
        toast({ title: "تم إضافة الزبون", description: `تم تسجيل ${newClient.name}` });
        // After creating client, proceed with transaction
        if (pendingTxRef.current) {
          const tx = pendingTxRef.current;
          pendingTxRef.current = null;
          createMutation.mutate({ data: { ...tx.data, clientId: newClient.id } });
        }
        setClientResolution({ kind: "idle" });
        setNewClientPhone("");
      },
    },
  });

  const createMutation = useCreateTransaction({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetRecentTransactionsQueryKey() });
        toast({ title: "تم الحفظ ✓", description: "تم تسجيل المعاملة بنجاح" });
        setLocation("/transactions");
      },
      onError: () => {
        toast({ title: "خطأ", description: "فشل حفظ المعاملة", variant: "destructive" });
      },
    },
  });

  // --- Voice recording (toggle mode) ---
  function toggleVoiceRecording() {
    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
      return;
    }

    type SpeechRecognitionCtor = new () => SpeechRecognition;
    const w = window as Window & {
      SpeechRecognition?: SpeechRecognitionCtor;
      webkitSpeechRecognition?: SpeechRecognitionCtor;
    };
    const Ctor = w.SpeechRecognition ?? w.webkitSpeechRecognition;

    if (!Ctor) {
      toast({
        title: "الصوت غير مدعوم",
        description: "متصفحك لا يدعم التسجيل الصوتي — استخدمي خانة النص أدناه",
        variant: "destructive",
      });
      return;
    }

    const recognition = new Ctor();
    recognition.lang = "ar-AE";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.continuous = false;

    recognition.onstart = () => setIsRecording(true);
    recognition.onend = () => setIsRecording(false);

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results[0][0].transcript;
      setTextInput(transcript);
      parseMutation.mutate({ data: { text: transcript } });
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      setIsRecording(false);
      if ((event as unknown as { error: string }).error === "not-allowed") {
        toast({
          title: "إذن الميكروفون مرفوض",
          description: "يرجى السماح للتطبيق باستخدام الميكروفون من إعدادات المتصفح",
          variant: "destructive",
        });
      } else {
        toast({
          title: "خطأ في التسجيل",
          description: "لم نتمكن من التسجيل — حاولي مرة أخرى",
          variant: "destructive",
        });
      }
    };

    recognition.start();
    recognitionRef.current = recognition;
  }

  function handleParseText() {
    if (!textInput.trim()) return;
    parseMutation.mutate({ data: { text: textInput } });
  }

  // --- Similarity check (simple Arabic-aware) ---
  function findSimilarClients(name: string): { id: number; name: string }[] {
    if (!clients || !name) return [];
    const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, " ");
    const n = norm(name);
    return clients
      .filter((c) => {
        const cn = norm(c.name);
        return cn === n || cn.includes(n) || n.includes(cn) ||
          // Check if words overlap
          n.split(" ").some((w) => w.length > 1 && cn.includes(w));
      })
      .map((c) => ({ id: c.id, name: c.name }));
  }

  // --- Build transaction payload from parsed data ---
  function buildTxPayload(clientId: number | null) {
    return {
      type: parsed?.type || "expense",
      amount: parsed?.amount || 0,
      currency: parsed?.currency || "AED",
      clientId,
      tripId: trips?.find((t) => t.name === parsed?.tripName)?.id ?? null,
      description: parsed?.description ?? null,
      status: "pending" as const,
      date: new Date().toISOString().split("T")[0],
    };
  }

  // --- Confirm step handler ---
  function handleConfirm() {
    if (!parsed) return;

    const clientName = parsed.clientName?.trim();

    if (!clientName) {
      // No client mentioned — save directly
      createMutation.mutate({ data: buildTxPayload(null) });
      return;
    }

    // Exact match (case-insensitive)
    const exact = clients?.find(
      (c) => c.name.trim().toLowerCase() === clientName.toLowerCase()
    );
    if (exact) {
      createMutation.mutate({ data: buildTxPayload(exact.id) });
      return;
    }

    // Similar matches
    const similar = findSimilarClients(clientName);
    if (similar.length > 0) {
      pendingTxRef.current = { data: buildTxPayload(null) };
      setClientResolution({ kind: "similar", matches: similar, inputName: clientName });
      return;
    }

    // Brand new client
    pendingTxRef.current = { data: buildTxPayload(null) };
    setClientResolution({ kind: "new", name: clientName });
  }

  // --- Client resolution actions ---
  function chooseExistingClient(id: number) {
    const tx = pendingTxRef.current;
    pendingTxRef.current = null;
    setClientResolution({ kind: "idle" });
    if (tx) createMutation.mutate({ data: { ...tx.data, clientId: id } });
  }

  function confirmNewClient(name: string) {
    createClientMutation.mutate({ data: { name, phone: newClientPhone || undefined } });
  }

  function skipClient() {
    const tx = pendingTxRef.current;
    pendingTxRef.current = null;
    setClientResolution({ kind: "idle" });
    if (tx) createMutation.mutate({ data: { ...tx.data, clientId: null } });
  }

  function handleManualSubmit(e: React.FormEvent) {
    e.preventDefault();
    createMutation.mutate({
      data: {
        type: manualForm.type,
        amount: parseFloat(manualForm.amount) || 0,
        currency: manualForm.currency,
        clientId: manualForm.clientId ? parseInt(manualForm.clientId) : null,
        tripId: manualForm.tripId ? parseInt(manualForm.tripId) : null,
        description: manualForm.description || null,
        status: manualForm.status,
        date: manualForm.date,
      },
    });
  }

  const isLoading = createMutation.isPending || createClientMutation.isPending;

  return (
    <div className="p-4 max-w-lg mx-auto pb-24 lg:pb-6">
      {/* Header */}
      <div className="flex items-center gap-3 pt-2 mb-6">
        <button
          onClick={() => setLocation("/transactions")}
          className="p-2 rounded-lg hover:bg-muted text-muted-foreground"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-xl font-bold">معاملة جديدة</h1>
          <p className="text-muted-foreground text-xs">تحدثي أو اكتبي العملية</p>
        </div>
      </div>

      {/* ── Client Resolution Modal ── */}
      {clientResolution.kind !== "idle" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div className="bg-card border border-border rounded-2xl shadow-2xl p-5 w-full max-w-sm">
            {clientResolution.kind === "similar" ? (
              <>
                <div className="flex items-center gap-2 mb-4">
                  <Users className="w-5 h-5 text-amber-500" />
                  <h2 className="font-bold text-foreground">هل تقصدين أحد هؤلاء؟</h2>
                </div>
                <p className="text-sm text-muted-foreground mb-3">
                  وجدنا زبائن بأسماء مشابهة لـ «{clientResolution.inputName}»:
                </p>
                <div className="space-y-2 mb-4">
                  {clientResolution.matches.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => chooseExistingClient(m.id)}
                      disabled={isLoading}
                      className="w-full flex items-center gap-3 p-3 bg-accent rounded-xl text-right hover:bg-primary/10 transition-colors disabled:opacity-50"
                      data-testid={`btn-choose-client-${m.id}`}
                    >
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm shrink-0">
                        {m.name.charAt(0)}
                      </div>
                      <span className="font-semibold text-sm">{m.name}</span>
                    </button>
                  ))}
                </div>
                <div className="border-t border-border pt-3 space-y-2">
                  <button
                    onClick={() => {
                      setClientResolution({ kind: "new", name: clientResolution.inputName });
                    }}
                    className="w-full flex items-center justify-center gap-2 border border-primary text-primary rounded-xl py-2.5 text-sm font-semibold hover:bg-primary/10 transition-colors"
                    data-testid="btn-new-client-from-similar"
                  >
                    <UserPlus className="w-4 h-4" />
                    لا، هذا زبون جديد: «{clientResolution.inputName}»
                  </button>
                  <button
                    onClick={skipClient}
                    disabled={isLoading}
                    className="w-full text-muted-foreground text-sm py-2 hover:text-foreground transition-colors"
                    data-testid="btn-skip-client"
                  >
                    تجاهل الزبون وحفظ بدونه
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-2 mb-4">
                  <UserPlus className="w-5 h-5 text-primary" />
                  <h2 className="font-bold text-foreground">زبون جديد</h2>
                </div>
                <p className="text-sm text-muted-foreground mb-1">الاسم</p>
                <div className="bg-accent rounded-xl px-3 py-2 mb-4 font-semibold text-foreground">
                  {clientResolution.name}
                </div>
                <label className="text-sm text-muted-foreground mb-1 block">
                  رقم الهاتف <span className="text-muted-foreground/60">(اختياري)</span>
                </label>
                <input
                  type="tel"
                  value={newClientPhone}
                  onChange={(e) => setNewClientPhone(e.target.value)}
                  placeholder="05XXXXXXXX"
                  className="w-full border border-border rounded-xl px-4 py-2.5 text-sm bg-background mb-4 focus:outline-none focus:ring-2 focus:ring-primary/30"
                  data-testid="input-new-client-phone"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === "Enter") confirmNewClient(clientResolution.name);
                  }}
                />
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={skipClient}
                    disabled={isLoading}
                    className="border border-border rounded-xl py-2.5 text-sm font-semibold text-muted-foreground hover:bg-muted transition-colors disabled:opacity-50"
                    data-testid="btn-skip-new-client"
                  >
                    تجاهل
                  </button>
                  <button
                    onClick={() => confirmNewClient(clientResolution.name)}
                    disabled={isLoading}
                    className="bg-primary text-primary-foreground rounded-xl py-2.5 text-sm font-semibold disabled:opacity-50 flex items-center justify-center gap-2"
                    data-testid="btn-confirm-new-client"
                  >
                    {isLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <UserPlus className="w-4 h-4" />
                    )}
                    إضافة وحفظ
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ── Step: Input ── */}
      {step === "input" ? (
        <div className="space-y-5">
          {/* Voice toggle button */}
          <div className="flex flex-col items-center py-8 bg-card border border-border rounded-2xl shadow-sm">
            <p className="text-sm text-muted-foreground mb-2 text-center px-4">
              اضغطي مرة للبدء، ومرة أخرى للإيقاف
            </p>
            <p className="text-xs text-muted-foreground/70 mb-5 text-center px-4">
              مثال: «اشتريت بضاعة لرشا بألف درهم رحلة دبي»
            </p>
            <button
              onClick={toggleVoiceRecording}
              disabled={parseMutation.isPending}
              className={cn(
                "w-24 h-24 rounded-full flex items-center justify-center shadow-lg transition-all duration-200 select-none",
                isRecording
                  ? "bg-red-500 scale-105 animate-recording"
                  : parseMutation.isPending
                  ? "bg-muted cursor-not-allowed"
                  : "bg-primary hover:bg-primary/90 active:scale-95"
              )}
              data-testid="btn-voice-record"
            >
              {parseMutation.isPending ? (
                <Loader2 className="w-9 h-9 text-white animate-spin" />
              ) : isRecording ? (
                <MicOff className="w-9 h-9 text-white" />
              ) : (
                <Mic className="w-9 h-9 text-white" />
              )}
            </button>
            {isRecording && (
              <p className="text-red-500 text-sm mt-4 font-semibold animate-pulse">
                🔴 جاري التسجيل... اضغطي للإيقاف
              </p>
            )}
            {parseMutation.isPending && (
              <p className="text-muted-foreground text-sm mt-4">جاري التحليل بالذكاء الاصطناعي...</p>
            )}
          </div>

          {/* Text input */}
          <div className="space-y-2">
            <p className="text-sm font-medium text-muted-foreground">أو اكتبي النص مباشرة</p>
            <div className="flex gap-2">
              <input
                type="text"
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleParseText()}
                placeholder='مثال: "قبضت 500 دولار من رشا"'
                className="flex-1 border border-border rounded-xl px-4 py-3 text-sm bg-card focus:outline-none focus:ring-2 focus:ring-primary/30"
                data-testid="input-text-transaction"
              />
              <button
                onClick={handleParseText}
                disabled={parseMutation.isPending || !textInput.trim()}
                className="bg-primary text-primary-foreground px-4 py-3 rounded-xl text-sm font-semibold disabled:opacity-50 whitespace-nowrap"
                data-testid="btn-parse-text"
              >
                {parseMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "تحليل"}
              </button>
            </div>
          </div>

          {/* Divider */}
          <div className="flex items-center gap-3">
            <div className="flex-1 h-px bg-border" />
            <span className="text-xs text-muted-foreground">أو أدخلي يدوياً</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          {/* Manual form */}
          <form onSubmit={handleManualSubmit} className="bg-card border border-border rounded-2xl p-4 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">النوع</label>
                <select
                  value={manualForm.type}
                  onChange={(e) => setManualForm({ ...manualForm, type: e.target.value })}
                  className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-background"
                  data-testid="select-type"
                >
                  <option value="income">دخل</option>
                  <option value="expense">مصروف</option>
                  <option value="payment">دفع</option>
                  <option value="receipt">قبض</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">العملة</label>
                <select
                  value={manualForm.currency}
                  onChange={(e) => setManualForm({ ...manualForm, currency: e.target.value })}
                  className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-background"
                  data-testid="select-currency"
                >
                  <option value="AED">درهم AED</option>
                  <option value="USD">دولار USD</option>
                  <option value="SYP">ليرة SYP</option>
                </select>
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">المبلغ</label>
              <input
                type="number"
                value={manualForm.amount}
                onChange={(e) => setManualForm({ ...manualForm, amount: e.target.value })}
                placeholder="0.00"
                className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-background"
                data-testid="input-amount"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">الزبون</label>
                <select
                  value={manualForm.clientId}
                  onChange={(e) => setManualForm({ ...manualForm, clientId: e.target.value })}
                  className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-background"
                  data-testid="select-client"
                >
                  <option value="">بدون زبون</option>
                  {clients?.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">الرحلة</label>
                <select
                  value={manualForm.tripId}
                  onChange={(e) => setManualForm({ ...manualForm, tripId: e.target.value })}
                  className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-background"
                  data-testid="select-trip"
                >
                  <option value="">بدون رحلة</option>
                  {trips?.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">التاريخ</label>
              <input
                type="date"
                value={manualForm.date}
                onChange={(e) => setManualForm({ ...manualForm, date: e.target.value })}
                className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-background"
                data-testid="input-date"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">الوصف</label>
              <input
                type="text"
                value={manualForm.description}
                onChange={(e) => setManualForm({ ...manualForm, description: e.target.value })}
                placeholder="وصف اختياري"
                className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-background"
                data-testid="input-description"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">الحالة</label>
              <select
                value={manualForm.status}
                onChange={(e) => setManualForm({ ...manualForm, status: e.target.value })}
                className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-background"
                data-testid="select-status"
              >
                <option value="pending">معلقة</option>
                <option value="settled">مسددة</option>
              </select>
            </div>
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-primary text-primary-foreground py-3 rounded-xl text-sm font-semibold disabled:opacity-50 flex items-center justify-center gap-2"
              data-testid="btn-submit-manual"
            >
              {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
              حفظ المعاملة
            </button>
          </form>
        </div>
      ) : (
        /* ── Step: Confirm ── */
        <div className="space-y-4">
          <div className="bg-card border-2 border-primary/20 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              <CheckCircle className="w-5 h-5 text-primary" />
              <h2 className="font-bold text-foreground">تأكيد المعاملة</h2>
            </div>

            {parsed?.rawText && (
              <div className="bg-muted rounded-xl p-3 mb-4">
                <p className="text-xs text-muted-foreground mb-1">النص الأصلي</p>
                <p className="text-sm text-foreground">{parsed.rawText}</p>
              </div>
            )}

            <div className="space-y-0">
              {[
                { label: "نوع العملية", value: parsed?.type ? typeLabel(parsed.type) : null },
                {
                  label: "المبلغ",
                  value:
                    parsed?.amount && parsed?.currency
                      ? formatAmount(parsed.amount, parsed.currency)
                      : null,
                  bold: true,
                },
                {
                  label: "العملة",
                  value: parsed?.currency,
                  badge: parsed?.currency ? currencyClass(parsed.currency) : undefined,
                },
                { label: "الزبون", value: parsed?.clientName },
                { label: "الرحلة", value: parsed?.tripName },
                { label: "الوصف", value: parsed?.description },
              ]
                .filter((r) => r.value)
                .map((row, i, arr) => (
                  <div
                    key={row.label}
                    className={cn(
                      "flex items-center justify-between py-2.5",
                      i < arr.length - 1 ? "border-b border-border" : ""
                    )}
                  >
                    <span className="text-sm text-muted-foreground">{row.label}</span>
                    {row.badge ? (
                      <span className={cn("text-xs font-bold px-2 py-1 rounded-full", row.badge)}>
                        {row.value}
                      </span>
                    ) : (
                      <span className={cn("text-sm font-semibold", row.bold ? "text-primary text-base" : "")}>
                        {row.value}
                      </span>
                    )}
                  </div>
                ))}
            </div>

            {/* Client status indicator */}
            {parsed?.clientName && (
              <div className="mt-3 pt-3 border-t border-border">
                {clients?.find(
                  (c) => c.name.trim().toLowerCase() === parsed.clientName?.trim().toLowerCase()
                ) ? (
                  <div className="flex items-center gap-2 text-green-600 text-xs">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>زبون موجود — سيتم ربطه تلقائياً</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-amber-600 text-xs">
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>
                      «{parsed.clientName}» —{" "}
                      {findSimilarClients(parsed.clientName).length > 0
                        ? "سيُطلب منكِ التأكيد على الاسم"
                        : "زبون جديد، ستتمكنين من إضافة رقم هاتفه"}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => {
                setParsed(null);
                setStep("input");
                setTextInput("");
              }}
              className="flex items-center justify-center gap-2 border border-border rounded-xl py-3 text-sm font-semibold text-muted-foreground hover:bg-muted transition-colors"
              data-testid="btn-cancel-confirm"
            >
              <XCircle className="w-4 h-4" />
              إلغاء
            </button>
            <button
              onClick={handleConfirm}
              disabled={isLoading}
              className="flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-xl py-3 text-sm font-semibold disabled:opacity-50"
              data-testid="btn-confirm-transaction"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <CheckCircle className="w-4 h-4" />
              )}
              تأكيد الحفظ
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
