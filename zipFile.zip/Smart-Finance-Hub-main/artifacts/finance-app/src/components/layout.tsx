import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  ArrowLeftRight,
  Users,
  Route,
  Building2,
  MessageCircle,
  Plus,
  Menu,
  X,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", icon: LayoutDashboard, label: "الرئيسية" },
  { href: "/transactions", icon: ArrowLeftRight, label: "المعاملات" },
  { href: "/clients", icon: Users, label: "الزبائن" },
  { href: "/trips", icon: Route, label: "الرحلات" },
  { href: "/studios", icon: Building2, label: "الاستديوهات" },
  { href: "/chat", icon: MessageCircle, label: "المساعد الذكي" },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex h-screen bg-background overflow-hidden" dir="rtl">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed right-0 top-0 h-full w-64 bg-sidebar z-50 flex flex-col transition-transform duration-300 lg:relative lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "translate-x-full"
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-sidebar-border">
          <div>
            <h1 className="text-white font-bold text-lg leading-tight">حسابات</h1>
            <p className="text-sidebar-foreground/60 text-xs mt-0.5">نظام إدارة مالي</p>
          </div>
          <button
            className="lg:hidden text-sidebar-foreground/60 hover:text-white p-1"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick add button */}
        <div className="px-4 pt-4">
          <Link href="/transactions/new" onClick={() => setSidebarOpen(false)}>
            <button
              className="w-full flex items-center gap-2 bg-sidebar-primary hover:bg-sidebar-primary/90 text-sidebar-primary-foreground rounded-xl px-4 py-3 text-sm font-semibold transition-colors"
              data-testid="btn-new-transaction"
            >
              <Plus className="w-4 h-4" />
              معاملة جديدة
            </button>
          </Link>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map(({ href, icon: Icon, label }) => {
            const isActive = href === "/" ? location === "/" : location.startsWith(href);
            return (
              <Link key={href} href={href} onClick={() => setSidebarOpen(false)}>
                <div
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer",
                    isActive
                      ? "bg-sidebar-accent text-white"
                      : "text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-white"
                  )}
                  data-testid={`nav-${href.replace("/", "") || "home"}`}
                >
                  <Icon className="w-5 h-5 shrink-0" />
                  {label}
                </div>
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-sidebar-border">
          <p className="text-sidebar-foreground/40 text-xs text-center">v1.0</p>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar (mobile) */}
        <header className="lg:hidden flex items-center justify-between px-4 py-3 bg-card border-b border-border shrink-0">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 rounded-lg hover:bg-muted"
            data-testid="btn-menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          <h1 className="font-bold text-foreground">حسابات</h1>
          <Link href="/transactions/new">
            <button className="p-2 rounded-lg bg-primary text-primary-foreground" data-testid="btn-quick-add">
              <Plus className="w-4 h-4" />
            </button>
          </Link>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">{children}</main>

        {/* Bottom nav (mobile) */}
        <nav className="lg:hidden flex items-center justify-around bg-card border-t border-border py-2 px-2 shrink-0">
          {navItems.slice(0, 5).map(({ href, icon: Icon, label }) => {
            const isActive = href === "/" ? location === "/" : location.startsWith(href);
            return (
              <Link key={href} href={href}>
                <div
                  className={cn(
                    "flex flex-col items-center gap-0.5 px-2 py-1 rounded-lg transition-colors",
                    isActive ? "text-primary" : "text-muted-foreground"
                  )}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-[10px] font-medium">{label}</span>
                </div>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
