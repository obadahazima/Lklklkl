import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatAmount(amount: number, currency: string): string {
  const symbols: Record<string, string> = { AED: "د.إ", USD: "$", SYP: "ل.س" };
  const sym = symbols[currency] || currency;
  const formatted = new Intl.NumberFormat("ar-AE").format(Math.abs(amount));
  return `${formatted} ${sym}`;
}

export function currencyClass(currency: string): string {
  if (currency === "AED") return "currency-aed";
  if (currency === "USD") return "currency-usd";
  if (currency === "SYP") return "currency-syp";
  return "";
}

export function typeLabel(type: string): string {
  const labels: Record<string, string> = { income: "دخل", expense: "مصروف", payment: "دفع", receipt: "قبض" };
  return labels[type] || type;
}

export function typeClass(type: string): string {
  const classes: Record<string, string> = { income: "type-income", expense: "type-expense", payment: "type-payment", receipt: "type-receipt" };
  return classes[type] || "";
}

export function statusLabel(status: string): string {
  const labels: Record<string, string> = { pending: "معلقة", settled: "مسددة", active: "نشطة", closed: "مغلقة" };
  return labels[status] || status;
}

export function statusClass(status: string): string {
  const classes: Record<string, string> = { pending: "status-pending", settled: "status-settled", active: "status-active", closed: "status-closed" };
  return classes[status] || "";
}

export function formatDate(date: string): string {
  try {
    return new Date(date).toLocaleDateString("ar-AE", { year: "numeric", month: "short", day: "numeric" });
  } catch { return date; }
}
